# Bab Ul Ilm Raza E Mustafa — Complete Cloud-Build Android Project

App name: Bab Ul Ilm Raza E Mustafa
App ID / package: com.babulilm.razaemustafa
Version: 2.0.0

## Easiest cloud build
1. Upload this project to a GitHub repository from your phone.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**.
4. Tap **Run workflow**.
5. When it finishes, open the workflow run and download the artifact named **Bab-Ul-Ilm-Raza-E-Mustafa-debug-apk**.

The Android wrapper is native Java + WebView, so the `android/` platform is already present. No `npx cap add android` step is required.

## Important
The bundled UI is the latest local UI build. Firebase backend wiring is not enabled in this UI package yet; Firebase rules are not included as active app code. This package is for building/installing the UI as an Android APK.
