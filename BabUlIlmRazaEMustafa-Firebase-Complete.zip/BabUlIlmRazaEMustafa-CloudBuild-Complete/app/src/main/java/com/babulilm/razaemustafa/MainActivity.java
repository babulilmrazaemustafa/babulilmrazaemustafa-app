package com.babulilm.razaemustafa;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int FILE_PICKER = 701;
    private static final int NOTIFICATION_PERMISSION = 702;
    private WebView webView;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private FirebaseAnalytics analytics;
    private ValueCallback<Uri[]> pendingFileCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w=getWindow();
        w.setStatusBarColor(Color.rgb(6,37,29));
        w.setNavigationBarColor(Color.rgb(6,37,29));

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        analytics = FirebaseAnalytics.getInstance(this);

        webView=new WebView(this); setContentView(webView);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setBackgroundColor(Color.WHITE);
        webView.addJavascriptInterface(new FirebaseBridge(), "AndroidFirebase");
        webView.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                pendingFileCallback = callback;
                Intent i = params.createIntent();
                try { startActivityForResult(i, FILE_PICKER); } catch (Exception e) { callback.onReceiveValue(null); pendingFileCallback=null; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/www/index.html");

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful() && auth.getCurrentUser() != null) saveToken(task.getResult());
        });
    }

    private void saveToken(String token) {
        FirebaseUser u = auth.getCurrentUser(); if (u == null || token == null) return;
        Map<String,Object> data = new HashMap<>();
        data.put("token", token); data.put("updatedAt", System.currentTimeMillis());
        db.collection("users").document(u.getUid()).collection("devices").document(token).set(data, SetOptions.merge());
    }

    private void js(String fn, String payload) {
        String safe = JSONObject.quote(payload == null ? "" : payload);
        runOnUiThread(() -> webView.evaluateJavascript("window." + fn + "(" + safe + ");", null));
    }

    public class FirebaseBridge {
        @JavascriptInterface public void status() {
            FirebaseUser u=auth.getCurrentUser();
            String out = u==null ? "{}" : "{\"uid\":\""+u.getUid()+"\",\"email\":\""+(u.getEmail()==null?"":u.getEmail())+"\",\"name\":\""+(u.getDisplayName()==null?"":u.getDisplayName())+"\"}";
            js("onFirebaseStatus", out);
        }
        @JavascriptInterface public void signUp(String email,String password,String name) {
            auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(task -> {
                if (!task.isSuccessful()) { js("onFirebaseAuthResult", "ERROR:"+task.getException().getMessage()); return; }
                FirebaseUser u=auth.getCurrentUser();
                if (u==null) return;
                u.updateProfile(new UserProfileChangeRequest.Builder().setDisplayName(name).build()).addOnCompleteListener(x -> {
                    Map<String,Object> user=new HashMap<>(); user.put("uid",u.getUid()); user.put("email",email); user.put("name",name); user.put("createdAt",System.currentTimeMillis());
                    db.collection("users").document(u.getUid()).set(user, SetOptions.merge());
                    FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> { if(t.isSuccessful()) saveToken(t.getResult()); });
                    js("onFirebaseAuthResult", "OK");
                });
            });
        }
        @JavascriptInterface public void signIn(String email,String password) {
            auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(task -> {
                if (!task.isSuccessful()) { js("onFirebaseAuthResult", "ERROR:"+task.getException().getMessage()); return; }
                FirebaseUser u=auth.getCurrentUser();
                if(u!=null){ FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t->{if(t.isSuccessful())saveToken(t.getResult());}); }
                js("onFirebaseAuthResult", "OK");
            });
        }
        @JavascriptInterface public void signOut() { auth.signOut(); js("onFirebaseAuthResult", "SIGNED_OUT"); }
        @JavascriptInterface public void saveRegistration(String name,String level,String mobile,String email) {
            Map<String,Object> r=new HashMap<>(); r.put("name",name); r.put("level",level); r.put("mobile",mobile); r.put("email",email); r.put("createdAt",System.currentTimeMillis());
            String id = auth.getCurrentUser()!=null ? auth.getCurrentUser().getUid() : db.collection("registrations").document().getId();
            db.collection("registrations").document(id).set(r).addOnCompleteListener(t -> js("onFirebaseDataResult", t.isSuccessful()?"OK":"ERROR:"+(t.getException()==null?"Save failed":t.getException().getMessage())));
        }
        @JavascriptInterface public void sendChat(String text) {
            Map<String,Object> m=new HashMap<>(); m.put("text",text); m.put("createdAt",System.currentTimeMillis());
            FirebaseUser u=auth.getCurrentUser(); if(u!=null){m.put("uid",u.getUid());m.put("email",u.getEmail());}
            db.collection("chat_messages").add(m).addOnCompleteListener(t -> js("onFirebaseDataResult", t.isSuccessful()?"OK":"ERROR:"+(t.getException()==null?"Send failed":t.getException().getMessage())));
        }
        @JavascriptInterface public void uploadFile() {
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,FILE_PICKER);
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=FILE_PICKER) return;
        Uri uri=(resultCode==RESULT_OK && data!=null)?data.getData():null;
        if(pendingFileCallback!=null){pendingFileCallback.onReceiveValue(uri==null?null:new Uri[]{uri});pendingFileCallback=null;}
        if(uri!=null){
            FirebaseUser u=auth.getCurrentUser();
            if(u==null){js("onFirebaseDataResult","ERROR:Please login first");return;}
            String name="file_"+System.currentTimeMillis();
            com.google.firebase.storage.StorageReference ref=storage.getReference().child("uploads/"+u.getUid()+"/"+name);
            ref.putFile(uri).continueWithTask(t->ref.getDownloadUrl()).addOnCompleteListener(t->js("onFirebaseUploadResult", t.isSuccessful()?t.getResult().toString():"ERROR:"+(t.getException()==null?"Upload failed":t.getException().getMessage())));
        }
    }

    @Override public void onBackPressed() { if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
