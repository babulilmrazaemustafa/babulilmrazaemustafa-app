package com.babulilm.razaemustafa;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.messaging.RemoteMessage;

import java.util.HashMap;
import java.util.Map;

public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {
    private static final String CHANNEL_ID="bab_ul_ilm_notifications";
    @Override public void onNewToken(String token){
        if(FirebaseAuth.getInstance().getCurrentUser()!=null){
            String uid=FirebaseAuth.getInstance().getCurrentUser().getUid();
            Map<String,Object> m=new HashMap<>(); m.put("token",token); m.put("updatedAt",System.currentTimeMillis());
            FirebaseFirestore.getInstance().collection("users").document(uid).collection("devices").document(token).set(m, SetOptions.merge());
        }
    }
    @Override public void onMessageReceived(RemoteMessage msg){
        String title=msg.getNotification()!=null && msg.getNotification().getTitle()!=null?msg.getNotification().getTitle():"Bab Ul Ilm Raza E Mustafa";
        String body=msg.getNotification()!=null && msg.getNotification().getBody()!=null?msg.getNotification().getBody():"New notification";
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,"Bab Ul Ilm Notifications",NotificationManager.IMPORTANCE_DEFAULT));
        Intent i=new Intent(this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        android.app.Notification.Builder b;
        if(Build.VERSION.SDK_INT>=26) b=new android.app.Notification.Builder(this,CHANNEL_ID);
        else b=new android.app.Notification.Builder(this);
        b.setSmallIcon(com.babulilm.razaemustafa.R.mipmap.ic_launcher).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi);
        nm.notify((int)System.currentTimeMillis(),b.build());
    }
}
