# Bab Ul Ilm Raza E Mustafa — Firebase Complete

Connected Firebase Android app: `com.babulilm.razaemustafa`.

Included: Email/Password Authentication, Cloud Firestore, Cloud Storage, FCM, Analytics and Crashlytics.

Console setup:
1. Authentication → Sign-in method → enable Email/Password.
2. Firestore Database → Create database.
3. Storage → Get started.
4. Cloud Messaging → configure notifications.
5. Publish `firebase/firestore.rules` in Firestore Rules.
6. Publish `firebase/storage.rules` in Storage Rules.
